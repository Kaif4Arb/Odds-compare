# Odds Compare

A simple React app to compare odds.
