function App() {
  return <div>Odds Compare App</div>;
}

export default App;
