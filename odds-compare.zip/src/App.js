
import React from 'react';

function App() {
  return (
    <div style={{ padding: 20, fontFamily: 'Arial', textAlign: 'center' }}>
      <h1>Odds Compare</h1>
      <p>Welcome! More features coming soon.</p>
    </div>
  );
}

export default App;
