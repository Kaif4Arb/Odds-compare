# Odds Compare

This is a simple mobile-friendly React app for comparing odds from Mostbet, Parimatch, and 1xBet.